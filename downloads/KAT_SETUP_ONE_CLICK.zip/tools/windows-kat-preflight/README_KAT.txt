MYWORKSTATION - KAT STORE MODE

1. Από το Super Admin ανοίξτε το κατάστημα ΚΑΤ.
2. Πατήστε «Εγκαταστάσεις / Τερματικά», δημιουργήστε το συγκεκριμένο POS και αντιγράψτε το εφάπαξ link εγκατάστασης.
3. Εκτελέστε:
   INSTALL_KAT.cmd "https://myworkstation-app.onrender.com/store/STORE_ID?terminal=KAT-POS-01&activation=ONE_TIME_TOKEN"
4. Ο read-only προέλεγχος εκτελείται πρώτος. Αν βρει blocker, η εγκατάσταση σταματά.
5. Πριν τον προέλεγχο επαληθεύονται τα SHA-256 του installation/recovery package.
6. Με επιτυχία δημιουργείται συντόμευση χωρίς τον μυστικό κωδικό και ανοίγει μία φορά το link ενεργοποίησης στο συγκεκριμένο PC.
7. Για δεύτερο PC δημιουργήστε άλλο Terminal ID και χρησιμοποιήστε αποκλειστικά το δικό του link.

RECOVERY
Πριν από ανάκτηση εκτελέστε RECOVER_KAT_DRY_RUN.cmd. Δημιουργεί recovery report με app/schema revision και SHA-256 χωρίς αλλαγή συντόμευσης.
Μόνο αν το dry-run γράψει DRY_RUN_PASSED και υπάρχει εγκεκριμένο maintenance window, εκτελέστε RECOVER_KAT.cmd.
Η ανάκτηση χρησιμοποιεί μόνο το αποθηκευμένο, ελεγμένο HTTPS Store Mode URL.
Πριν αντικαταστήσει υπάρχουσα συντόμευση κρατά αντίγραφο ασφαλείας.
Αν δεν υπάρχει έγκυρο installation state, σταματά χωρίς αλλαγές.

Δεν απαιτούνται Node, npm, Git ή κωδικός χρήστη.
Δεν αλλάζει RBS, Kiosk Manager, CapDriver, υπηρεσίες Windows ή registry.
Ο RBS Observer είναι ξεχωριστή τεχνική εγκατάσταση και δεν ενεργοποιείται από εδώ.

Για την πραγματική δοκιμή ακολουθήστε με τη σειρά το KAT_REAL_TEST_CHECKLIST.txt.
